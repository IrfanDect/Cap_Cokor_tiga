def main(net,stat):
    return net + stat;

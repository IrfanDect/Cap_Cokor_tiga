from rich import print
from rich.console import Console
from rich.align import Align



def cli():
    return {"name":"asu","size":"77882368873298987230932-43-032098430987","nomor":"882378876328787342"}
